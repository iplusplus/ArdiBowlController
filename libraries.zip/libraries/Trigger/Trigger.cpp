/*
	Trigger.h is a library to retrieve either a rising or falling edge from a boolean value.
	Call update, then call the trigger output.
	Created by M. Lazarides, 3rd April 2015
*/

#include "Arduino.h"
#include "Trigger.h"

// get
Trigger::Trigger()
{

}
// record the current state
void Trigger::update(int boolVar)
{
	//get the falling or rising.
	if(boolVar != prevState)
	{
		if(boolVar = true)
			Rising = true;
		
		if(boolVar = false)
			Falling = true;
	}
	else
	{
		Rising = false;
		Falling = false;
	}
	_prevVarState = boolVar;
}