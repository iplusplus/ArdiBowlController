/*
	Trigger.h is a library to retrieve either a rising or falling edge from a boolean value.
	Created by M. Lazarides, 3rd April 2015
*/

#ifndef Trigger_h
#define Trigger_h

#include "Arduino.h"

class Trigger
{
  public:
	Trigger();
	void update(int boolVar);
	boolean Rising;
	boolean Falling;
  private:
    int _prevPinState;

};


#endif